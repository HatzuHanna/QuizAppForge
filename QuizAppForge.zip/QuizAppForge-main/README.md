Frontend Developer Quiz

This repository contains my completed quiz project for the Frontend Developer Quiz Test. The goal was to build a responsive, interactive quiz app using the provided Figma designs and Quiz API. I focused on delivering a high-quality, well-structured codebase and user-friendly experience.
