import "./App.css";
import Quizzler from "./components/Quizzler";


function App() {
  return (
    <div>
    
    <Quizzler />
    
    </div>
  );
}

export default App;
